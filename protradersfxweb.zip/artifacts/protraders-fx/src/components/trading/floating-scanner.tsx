import { useEffect, useRef, useState, type PointerEvent as ReactPointerEvent } from "react"
import { Activity, ArrowRight, GripHorizontal, Loader2, RefreshCw, ShieldCheck, X } from "lucide-react"
import {
  getGetMarketCandlesQueryKey,
  getGetMarketTickerQueryKey,
  getGetSessionStatusQueryKey,
  useAnalyzeMarket,
  useScanBestMarket,
  useGetMarketCandles,
  useGetMarketTicker,
  useGetSessionStatus,
} from "@workspace/api-client-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { formatVolatility } from "@/lib/format"
import { DEFAULT_MARKET_SYMBOL, marketLabel } from "@/lib/markets"
import { useDerivMarkets } from "@/hooks/use-deriv-markets"

type ScannerResult = {
  symbol: string
  asOf: string
  source: "deterministic" | "ai-advisory"
  advisoryOnly: true
  winRate?: number
  indicators: { ema9: number; ema21: number; rsi14: number; macdHistogram: number; trend: string; volatilityPct?: number; volatilityLevel?: string }
  analysis: { summary: string; bias: "bullish" | "bearish" | "neutral"; observations: string[]; limitations: string }
}

export function FloatingScanner() {
  const { data: session } = useGetSessionStatus({ query: { queryKey: getGetSessionStatusQueryKey() } })
  const [open, setOpen] = useState(false)
  const [symbol, setSymbol] = useState(DEFAULT_MARKET_SYMBOL)
  const marketQuery = useDerivMarkets()
  const scannerMarkets = marketQuery.volatilityMarkets.length ? marketQuery.volatilityMarkets : marketQuery.markets
  useEffect(() => {
    if (scannerMarkets.length && !scannerMarkets.some(item => item.symbol === symbol)) setSymbol(marketQuery.defaultSymbol)
  }, [scannerMarkets, marketQuery.defaultSymbol, symbol])
  const [position, setPosition] = useState(() => {
    if (typeof window === "undefined") return { x: 0, y: 0 }
    try {
      const saved = JSON.parse(window.localStorage.getItem("protraders-ai-position") || "null")
      return Number.isFinite(saved?.x) && Number.isFinite(saved?.y) ? { x: saved.x, y: saved.y } : { x: 0, y: 0 }
    } catch {
      return { x: 0, y: 0 }
    }
  })
  const [result, setResult] = useState<ScannerResult | null>(null)
  const [bestMarket, setBestMarket] = useState<any>(null)
  const [error, setError] = useState("")
  const drag = useRef<{ x: number; y: number; startX: number; startY: number } | null>(null)
  const wasDragged = useRef(false)
  const analyzeMarket = useAnalyzeMarket()
  const scanBestMarket = useScanBestMarket()
  const ticker = useGetMarketTicker(symbol, { query: { queryKey: getGetMarketTickerQueryKey(symbol), enabled: !!session?.authenticated && open, refetchInterval: 15000 } })
  const candleParams = { count: 60, granularity: 60 }
  const candles = useGetMarketCandles(symbol, candleParams, { query: { queryKey: getGetMarketCandlesQueryKey(symbol, candleParams), enabled: !!session?.authenticated && open, staleTime: 30000 } })

  useEffect(() => {
    const show = () => setOpen(true)
    window.addEventListener("protraders:open-scanner", show)
    return () => window.removeEventListener("protraders:open-scanner", show)
  }, [])

  useEffect(() => {
    window.localStorage.setItem("protraders-ai-position", JSON.stringify(position))
  }, [position])

  const analyze = () => {
    setError("")
    setBestMarket(null)
    analyzeMarket.mutate({ data: { symbol } }, {
      onSuccess: (body) => setResult(body as ScannerResult),
      onError: (scannerError) => setError(scannerError instanceof Error ? scannerError.message : "Scanner unavailable"),
    })
  }

  const runBestMarketScan = () => {
    setError("")
    scanBestMarket.mutate(undefined, {
      onSuccess: (body) => {
        const best = (body as any)?.best
        if (!best) {
          setBestMarket(null)
          setError("No volatility market returned enough fresh data to rank.")
          return
        }
        setSymbol(best.symbol)
        setResult(null)
        setBestMarket(best)
      },
      onError: (scanError) => setError(scanError instanceof Error ? scanError.message : "Best-market scan unavailable"),
    })
  }

  const startDrag = (event: ReactPointerEvent<HTMLElement>) => {
    drag.current = { x: position.x, y: position.y, startX: event.clientX, startY: event.clientY }
    wasDragged.current = false
    event.currentTarget.setPointerCapture(event.pointerId)
  }
  const moveDrag = (event: ReactPointerEvent<HTMLElement>) => {
    if (!drag.current) return
    if (Math.abs(event.clientX - drag.current.startX) > 4 || Math.abs(event.clientY - drag.current.startY) > 4) {
      wasDragged.current = true
    }
    const mobile = window.innerWidth < 768
    // The mobile panel spans the available width, so keep it horizontally
    // anchored and let users reposition it vertically without losing it.
    const minX = mobile ? 0 : -(window.innerWidth - 390)
    const minY = -(window.innerHeight - (mobile ? 220 : 320))
    setPosition({
      x: Math.min(0, Math.max(minX, drag.current.x + event.clientX - drag.current.startX)),
      y: Math.min(0, Math.max(minY, drag.current.y + event.clientY - drag.current.startY)),
    })
  }

  if (!open) {
    return (
      <Button
        className="fixed bottom-5 right-5 z-[70] touch-none select-none cursor-grab gap-2 rounded-full shadow-[0_14px_50px_rgba(0,0,0,.45)] active:cursor-grabbing"
        style={{ transform: `translate(${position.x}px, ${position.y}px)` }}
        onPointerDown={startDrag}
        onPointerMove={moveDrag}
        onPointerUp={() => { drag.current = null }}
        onPointerCancel={() => { drag.current = null }}
        onLostPointerCapture={() => { drag.current = null }}
        onClick={(event) => {
          if (wasDragged.current) {
            event.preventDefault()
            wasDragged.current = false
            return
          }
          setOpen(true)
        }}
        title="Drag AI Scanner to move it, or click to open"
        data-testid="button-open-scanner"
      >
        <Activity className="h-4 w-4" /> AI Scanner
      </Button>
    )
  }

  const tick = ticker.data as any
  const candleData = candles.data as any
  const aiWinRate = Number.isFinite(Number(result?.winRate)) ? `${Number(result?.winRate).toFixed(1)}%` : "Not available"
  return (
    <aside
      className="fixed inset-x-3 bottom-3 z-[70] max-h-[82vh] overflow-hidden rounded-2xl border border-primary/25 bg-card/95 shadow-[0_24px_90px_rgba(0,0,0,.6)] backdrop-blur-xl md:inset-auto md:right-5 md:top-24 md:w-[370px]"
      style={{ transform: `translate(${position.x}px, ${position.y}px)` }}
      aria-label="Movable AI market scanner"
      data-testid="panel-ai-scanner"
    >
      <div
        className="flex touch-none select-none cursor-grab items-center justify-between border-b border-white/10 bg-secondary/40 px-4 py-3 active:cursor-grabbing"
        onPointerDown={startDrag}
        onPointerMove={moveDrag}
        onPointerUp={() => { drag.current = null }}
        onPointerCancel={() => { drag.current = null }}
        onLostPointerCapture={() => { drag.current = null }}
      >
        <div className="flex items-center gap-2">
          <GripHorizontal className="hidden h-4 w-4 text-muted-foreground md:block" />
          <Activity className="h-4 w-4 text-primary" />
          <span className="text-sm font-semibold">AI Market Scanner</span>
        </div>
          <Button variant="ghost" size="icon" className="h-7 w-7" onPointerDown={(event) => event.stopPropagation()} onClick={() => setOpen(false)} aria-label="Close scanner">
          <X className="h-4 w-4" />
        </Button>
      </div>
      <div className="max-h-[calc(82vh-48px)] space-y-4 overflow-y-auto p-4">
        {!session?.authenticated ? (
          <div className="space-y-4">
            <div className="rounded-xl border border-primary/20 bg-primary/5 p-4">
              <div className="flex items-center gap-2 text-sm font-semibold">
                <ShieldCheck className="h-4 w-4 text-primary" />
                Connect to scan live markets
              </div>
              <p className="mt-2 text-sm leading-6 text-muted-foreground">
                The scanner uses current Deriv market data and returns advisory context only. Connect your account to run a scan.
              </p>
            </div>
            <Button asChild className="w-full" data-testid="button-connect-scanner">
              <a href="/api/deriv/login">Connect Deriv account <ArrowRight className="ml-2 h-4 w-4" /></a>
            </Button>
            <div className="flex items-center gap-2 border-t border-white/10 pt-3 text-[10px] uppercase tracking-wider text-muted-foreground">
              <ShieldCheck className="h-3.5 w-3.5 text-primary" /> Advisory only · no order execution
            </div>
          </div>
        ) : (
          <>
        <div className="flex gap-2">
          <Select value={symbol} onValueChange={(value) => { setSymbol(value); setResult(null); setBestMarket(null); setError("") }}>
            <SelectTrigger className="bg-background/70"><SelectValue /></SelectTrigger>
            <SelectContent>{scannerMarkets.map(item => <SelectItem key={item.symbol} value={item.symbol}>{marketLabel(item, item.symbol)}</SelectItem>)}</SelectContent>
          </Select>
          <Button onClick={analyze} disabled={analyzeMarket.isPending || ticker.isLoading || candles.isLoading} data-testid="button-run-scanner">
            {analyzeMarket.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <RefreshCw className="h-4 w-4" />}
            <span className="sr-only">Run analysis</span>
          </Button>
        </div>
        <Button className="w-full" variant="outline" onClick={runBestMarketScan} disabled={scanBestMarket.isPending} data-testid="button-scan-best-market">
          {scanBestMarket.isPending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Activity className="mr-2 h-4 w-4" />}
          {scanBestMarket.isPending ? "Comparing fresh volatility markets..." : "Find highest observed hit rate"}
        </Button>
         <div className="grid grid-cols-3 gap-2">
          <Metric label="Latest quote" value={tick?.available === false ? "Offline" : String(tick?.quote ?? "—")} />
           <Metric label="Volatility" value={candleData?.indicators ? formatVolatility(candleData.indicators.volatilityLevel, candleData.indicators.volatilityPct) : "Unavailable"} />
            <Metric label="Observed hit rate" value={bestMarket?.observedSignalWinRate != null ? `${Number(bestMarket.observedSignalWinRate).toFixed(1)}%` : aiWinRate} />
        </div>
        {error && <div className="rounded-lg border border-destructive/30 bg-destructive/10 p-3 text-xs text-destructive">{error}</div>}
        {!result && !error && (
          <div className="rounded-xl border border-dashed border-white/10 p-5 text-center text-sm text-muted-foreground">
            Scan the selected market.
          </div>
        )}
         {bestMarket && (
           <div className="space-y-3 rounded-xl border border-primary/30 bg-primary/5 p-4">
             <div className="flex items-start justify-between gap-3">
               <div>
                 <div className="text-[10px] uppercase tracking-wider text-primary">Top market from fresh Deriv scan</div>
                 <div className="mt-1 text-lg font-semibold">{bestMarket.displayName || bestMarket.symbol}</div>
                 <div className="font-mono text-xs text-muted-foreground">{bestMarket.symbol}</div>
               </div>
               <Badge variant="success">{Number(bestMarket.observedSignalWinRate).toFixed(1)}% observed</Badge>
             </div>
             <div className="grid grid-cols-2 gap-2">
                <Metric label="Market" value={`${bestMarket.displayName || bestMarket.symbol} · ${bestMarket.symbol}`} />
                <Metric label="Volatility" value={formatVolatility(bestMarket.indicators?.volatilityLevel, bestMarket.indicators?.volatilityPct)} />
                <Metric label="Historical signal hit rate" value={`${Number(bestMarket.observedSignalWinRate).toFixed(1)}%`} />
                <Metric label="Signals tested" value={String(bestMarket.signalSampleSize)} />
             </div>
             <p className="text-xs leading-5 text-muted-foreground">This is a recent one-step candle backtest, not a guaranteed Deriv win percentage. Review the market and contract before placing any order.</p>
             <Button className="w-full" variant="outline" onClick={() => {
               const direction = bestMarket.bias === "bearish" ? "PUT" : "CALL"
               window.location.href = `/create-bot?symbol=${encodeURIComponent(bestMarket.symbol)}&contract=${direction}&source=ai_assisted`
             }} data-testid="button-review-best-market">
               Open Manual Trader <ArrowRight className="ml-1 h-3.5 w-3.5" />
             </Button>
           </div>
         )}
         {result && !bestMarket && (
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <Badge variant={result.analysis.bias === "neutral" ? "outline" : result.analysis.bias === "bullish" ? "success" : "destructive"}>
                {result.analysis.bias.toUpperCase()}
              </Badge>
              <span className="text-[10px] uppercase tracking-wider text-muted-foreground">{result.source === "ai-advisory" ? "AI explained" : "Deterministic fallback"}</span>
            </div>
            <p className="text-sm leading-6">{result.analysis.summary}</p>
            <div className="grid grid-cols-3 gap-2">
              <Metric label="RSI 14" value={result.indicators.rsi14.toFixed(1)} />
              <Metric label="EMA trend" value={result.indicators.trend} />
              <Metric label="MACD hist." value={result.indicators.macdHistogram.toFixed(4)} />
            </div>
             <div className="rounded-lg border border-primary/20 bg-primary/5 p-3">
               <div className="flex items-center justify-between gap-3">
                 <div>
                   <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Observed volatility</div>
                   <div className="mt-1 font-mono text-sm">{formatVolatility(result.indicators.volatilityLevel, result.indicators.volatilityPct)}</div>
                 </div>
                 <div className="flex flex-wrap justify-end gap-2">
                 <Button size="sm" variant="outline" onClick={() => {
                   const direction = result.analysis.bias === "bullish" ? "CALL" : result.analysis.bias === "bearish" ? "PUT" : "CALL"
                    window.location.href = `/create-bot?symbol=${encodeURIComponent(symbol)}&contract=${direction}&source=ai_assisted`
                 }} data-testid="button-review-ai-trade">
                    Review in Manual Trader <ArrowRight className="ml-1 h-3.5 w-3.5" />
                 </Button>
                 <Button size="sm" variant="outline" onClick={() => {
                    const direction = result.analysis.bias === "bullish" ? "CALL" : result.analysis.bias === "bearish" ? "PUT" : "CALL"
                    window.location.href = `/create-bot?symbol=${encodeURIComponent(symbol)}&contract=${direction}&source=ai_assisted`
                 }} data-testid="button-run-ai-bot">
                    Review & Run Manual Trader
                 </Button>
                 </div>
               </div>
             </div>
            <ul className="space-y-2 text-xs text-muted-foreground">
              {result.analysis.observations.map(item => <li key={item} className="rounded-md bg-secondary/35 p-2">• {item}</li>)}
            </ul>
            <p className="text-[11px] leading-5 text-muted-foreground">{result.analysis.limitations}</p>
          </div>
        )}
          {Array.isArray((scanBestMarket.data as any)?.markets) && !bestMarket && (
           <div className="space-y-2 rounded-xl border border-primary/20 bg-primary/5 p-3">
             <div className="flex items-center justify-between gap-3">
               <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Fresh-market ranking</div>
               <span className="text-[10px] text-muted-foreground">{(scanBestMarket.data as any)?.availableCount || 0} available</span>
             </div>
             {(scanBestMarket.data as any).markets.slice(0, 5).map((market: any, index: number) => (
               <button key={market.symbol} type="button" className="flex w-full items-center justify-between rounded-lg border border-white/10 bg-background/50 px-3 py-2 text-left hover:border-primary/40" onClick={() => {
                 const direction = market.bias === "bearish" ? "PUT" : "CALL"
                 window.location.href = `/create-bot?symbol=${encodeURIComponent(market.symbol)}&contract=${direction}&source=ai_assisted`
               }}>
                  <span><span className="mr-2 font-mono text-xs text-primary">#{index + 1}</span><span className="text-xs">{market.displayName}</span><span className="ml-2 font-mono text-[10px] text-muted-foreground">{market.symbol}</span><span className="ml-2 text-[10px] uppercase text-muted-foreground">{formatVolatility(market.indicators?.volatilityLevel, market.indicators?.volatilityPct)} · {market.bias} · {market.freshnessSeconds}s old</span></span>
                 <span className="font-mono text-xs">Score {market.score}</span>
               </button>
             ))}
             <p className="text-[10px] leading-4 text-muted-foreground">{(scanBestMarket.data as any).disclaimer}</p>
           </div>
         )}
        <div className="flex items-center gap-2 border-t border-white/10 pt-3 text-[10px] uppercase tracking-wider text-muted-foreground">
          <ShieldCheck className="h-3.5 w-3.5 text-primary" /> Advisory only · no order execution
        </div>
          <p className="text-[11px] leading-5 text-muted-foreground">The scanner ranks fresh markets by observed historical signal hit rate only. It does not claim a guaranteed win percentage.</p>
          </>
        )}
      </div>
    </aside>
  )
}

function Metric({ label, value }: { label: string; value: string }) {
  return <div className="rounded-lg border border-white/5 bg-background/55 p-2"><div className="text-[9px] uppercase tracking-wider text-muted-foreground">{label}</div><div className="mt-1 truncate font-mono text-xs">{value}</div></div>
}